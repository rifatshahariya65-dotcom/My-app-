import AsyncStorage from "@react-native-async-storage/async-storage";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Animated,
  Easing,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  Linking,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import * as Speech from "expo-speech";
import * as Clipboard from "expo-clipboard";
import {
  RecordingPresets,
  requestRecordingPermissionsAsync,
  setAudioModeAsync,
  useAudioRecorder,
} from "expo-audio";
import * as FileSystem from "expo-file-system/legacy";

import { ScreenContainer } from "@/components/screen-container";
import { NativeBannerAd } from "@/components/native-ads";
import { createInterstitialController, type InterstitialController } from "@/lib/interstitial-ad";
import { trpc } from "@/lib/trpc";

const STORAGE_KEY = "bangla-ai-chat.messages.v1";
const AUTO_SPEAK_KEY = "bangla-ai-chat.auto-speak.v1";
const FAVORITES_KEY = "bangla-ai-chat.favorites.v1";
const VOICE_SETTINGS_KEY = "bangla-ai-chat.voice-settings.v1";
const FACEBOOK_CONTACT_URL = "https://www.facebook.com/share/1Dw4or4yvv/";
const WHATSAPP_CONTACT_URL = "https://wa.me/qr/JQNHSBQ6KQLYO1";

type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: number;
};

type DeviceVoice = { identifier: string; language: string; name: string };

const starterPrompts = [
  "একটি ইমেইল লিখুন",
  "সহজ ভাষায় বুঝিয়ে দিন",
  "ইংরেজিতে অনুবাদ করুন",
  "পড়াশোনার পরিকল্পনা দিন",
];

const initialMessage: ChatMessage = {
  id: "welcome",
  role: "assistant",
  content: "আসসালামু আলাইকুম! আমি বাংলা AI। লেখা, পড়াশোনা, পরিকল্পনা বা যেকোনো প্রশ্নে আপনাকে সাহায্য করতে প্রস্তুত।",
  createdAt: Date.now(),
};

function TypingIndicator() {
  const progress = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const animation = Animated.loop(
      Animated.sequence([
        Animated.timing(progress, { toValue: 1, duration: 1050, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        Animated.timing(progress, { toValue: 0, duration: 1050, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      ]),
    );
    animation.start();
    return () => animation.stop();
  }, [progress]);

  const dotStyle = (offset: number) => ({
    opacity: progress.interpolate({ inputRange: [0, 0.33, 0.66, 1], outputRange: [0.35, offset === 0 ? 1 : 0.45, offset === 1 ? 1 : 0.45, 0.35] }),
    transform: [{ translateY: progress.interpolate({ inputRange: [0, 0.33, 0.66, 1], outputRange: [0, offset === 0 ? -4 : offset === 1 ? -4 : -2, offset === 0 ? 0 : offset === 1 ? 0 : -1, 0] }) }],
  });

  return (
    <View style={styles.typingDots} accessibilityLabel="AI উত্তর তৈরি করছে">
      {[0, 0.5, 1].map((offset) => <Animated.View key={offset} style={[styles.typingDot, dotStyle(offset)]} />)}
    </View>
  );
}

export default function HomeScreen() {
  const [messages, setMessages] = useState<ChatMessage[]>([initialMessage]);
  const [draft, setDraft] = useState("");
  const [isHydrated, setIsHydrated] = useState(false);
  const [lastFailedText, setLastFailedText] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [autoSpeak, setAutoSpeak] = useState(false);
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);
  const [favoriteMessages, setFavoriteMessages] = useState<ChatMessage[]>([]);
  const [favoritesHydrated, setFavoritesHydrated] = useState(false);
  const [showFavorites, setShowFavorites] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showAbout, setShowAbout] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedbackText, setFeedbackText] = useState("");
  const [feedbackStatus, setFeedbackStatus] = useState<"idle" | "success" | "error">("idle");
  const [speechLanguage, setSpeechLanguage] = useState("bn-BD");
  const [speechRate, setSpeechRate] = useState(0.92);
  const [selectedVoice, setSelectedVoice] = useState<string | null>(null);
  const [availableVoices, setAvailableVoices] = useState<DeviceVoice[]>([]);
  const [speechSettingsHydrated, setSpeechSettingsHydrated] = useState(false);
  const interstitialRef = useRef<InterstitialController | null>(null);
  const completedResponseCount = useRef(0);
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const recognitionRef = useRef<any>(null);
  const completion = trpc.chat.complete.useMutation();
  const transcribeMutation = trpc.voice.transcribe.useMutation();

  useEffect(() => {
    const controller = createInterstitialController();
    interstitialRef.current = controller;
    return () => {
      controller.dispose();
      interstitialRef.current = null;
    };
  }, []);

  useEffect(() => {
    setAudioModeAsync({ playsInSilentMode: true, allowsRecording: true }).catch(() => undefined);
    return () => {
      Speech.stop().catch(() => undefined);
      recognitionRef.current?.abort?.();
    };
  }, []);

  useEffect(() => {
    Speech.getAvailableVoicesAsync()
      .then((voices) => setAvailableVoices(voices as DeviceVoice[]))
      .catch(() => undefined);
    AsyncStorage.getItem(VOICE_SETTINGS_KEY)
      .then((stored) => {
        if (stored) {
          const settings = JSON.parse(stored) as { language?: string; rate?: number; voice?: string | null };
          if (settings.language) setSpeechLanguage(settings.language);
          if (typeof settings.rate === "number") setSpeechRate(settings.rate);
          if (settings.voice) setSelectedVoice(settings.voice);
        }
      })
      .catch(() => undefined)
      .finally(() => setSpeechSettingsHydrated(true));
  }, []);

  useEffect(() => {
    if (speechSettingsHydrated) AsyncStorage.setItem(VOICE_SETTINGS_KEY, JSON.stringify({ language: speechLanguage, rate: speechRate, voice: selectedVoice })).catch(() => undefined);
  }, [selectedVoice, speechLanguage, speechRate, speechSettingsHydrated]);

  useEffect(() => {
    AsyncStorage.getItem(AUTO_SPEAK_KEY)
      .then((stored) => setAutoSpeak(stored === "true"))
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    const key = FAVORITES_KEY;
    AsyncStorage.getItem(key)
      .then((stored) => {
        if (stored) setFavoriteMessages(JSON.parse(stored));
      })
      .catch(() => undefined)
      .finally(() => setFavoritesHydrated(true));
  }, []);

  useEffect(() => {
    if (favoritesHydrated) AsyncStorage.setItem(FAVORITES_KEY, JSON.stringify(favoriteMessages)).catch(() => undefined);
  }, [favoriteMessages, favoritesHydrated]);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY)
      .then((stored) => {
        if (stored) setMessages(JSON.parse(stored));
      })
      .catch(() => undefined)
      .finally(() => setIsHydrated(true));
  }, []);

  useEffect(() => {
    if (isHydrated) AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(messages)).catch(() => undefined);
  }, [isHydrated, messages]);

  const sendMessage = useCallback(async (textOverride?: string) => {
    const text = (textOverride ?? draft).trim();
    if (!text || completion.isPending) return;
    const userMessage: ChatMessage = { id: `${Date.now()}-user`, role: "user", content: text, createdAt: Date.now() };
    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    setDraft("");
    setLastFailedText(null);
    try {
      const result = await completion.mutateAsync({
        messages: nextMessages.filter((item) => item.id !== "welcome").map(({ role, content }) => ({ role, content })),
      });
      const assistantMessage: ChatMessage = { id: `${Date.now()}-assistant`, role: "assistant", content: result.text, createdAt: Date.now() };
      setMessages((current) => [...current, assistantMessage]);
      completedResponseCount.current += 1;
      if (Platform.OS !== "web" && completedResponseCount.current % 3 === 0 && interstitialRef.current) {
        interstitialRef.current.showIfReady();
      }
      if (autoSpeak) {
        await Speech.stop();
        setSpeakingMessageId(assistantMessage.id);
        Speech.speak(result.text, {
          language: speechLanguage,
          rate: speechRate,
          ...(selectedVoice ? { voice: selectedVoice } : {}),
          onDone: () => setSpeakingMessageId(null),
          onStopped: () => setSpeakingMessageId(null),
          onError: () => {
            setSpeakingMessageId(null);
            setVoiceError("উত্তরটি স্বয়ংক্রিয়ভাবে শোনানো যায়নি।");
          },
        });
      }
    } catch {
      setLastFailedText(text);
    }
  }, [autoSpeak, completion, draft, messages, selectedVoice, speechLanguage, speechRate]);

  const openContactLink = useCallback(async (url: string) => {
    try {
      await Linking.openURL(url);
    } catch {
      setVoiceError("লিংকটি খোলা যাচ্ছে না। আবার চেষ্টা করুন।");
    }
  }, []);

  const submitFeedback = useCallback(async () => {
    const text = feedbackText.trim();
    if (!text) {
      setFeedbackStatus("error");
      return;
    }
    try {
      const stored = await AsyncStorage.getItem("bangla-ai-chat.feedback.v1");
      const entries = stored ? JSON.parse(stored) : [];
      await AsyncStorage.setItem("bangla-ai-chat.feedback.v1", JSON.stringify([...entries, { text, createdAt: Date.now() }]));
      setFeedbackText("");
      setFeedbackStatus("success");
    } catch {
      setFeedbackStatus("error");
    }
  }, [feedbackText]);

  const toggleAutoSpeak = useCallback(() => {
    setAutoSpeak((current) => {
      const next = !current;
      AsyncStorage.setItem(AUTO_SPEAK_KEY, String(next)).catch(() => undefined);
      if (!next) {
        Speech.stop().catch(() => undefined);
        setSpeakingMessageId(null);
      }
      return next;
    });
  }, []);

  const speakMessage = useCallback(async (message: ChatMessage) => {
    try {
      if (speakingMessageId === message.id) {
        await Speech.stop();
        setSpeakingMessageId(null);
        return;
      }
      await Speech.stop();
      setSpeakingMessageId(message.id);
      Speech.speak(message.content, {
        language: speechLanguage,
        rate: speechRate,
        ...(selectedVoice ? { voice: selectedVoice } : {}),
        onDone: () => setSpeakingMessageId(null),
        onStopped: () => setSpeakingMessageId(null),
        onError: () => {
          setSpeakingMessageId(null);
          setVoiceError("উত্তরটি শোনানো যাচ্ছে না।");
        },
      });
    } catch {
      setSpeakingMessageId(null);
      setVoiceError("উত্তরটি শোনানো যাচ্ছে না।");
    }
  }, [selectedVoice, speakingMessageId, speechLanguage, speechRate]);

  const copyMessage = useCallback(async (message: ChatMessage) => {
    try {
      const copied = await Clipboard.setStringAsync(message.content);
      if (copied !== false) {
        setCopiedMessageId(message.id);
        setTimeout(() => setCopiedMessageId((current) => current === message.id ? null : current), 1800);
      } else {
        setVoiceError("উত্তরটি কপি করা যায়নি। আবার চেষ্টা করুন।");
      }
    } catch {
      setVoiceError("উত্তরটি কপি করা যায়নি। আবার চেষ্টা করুন।");
    }
  }, []);

  const toggleFavorite = useCallback((message: ChatMessage) => {
    setFavoriteMessages((current) => current.some((item) => item.id === message.id) ? current.filter((item) => item.id !== message.id) : [...current, message]);
  }, []);

  const startNewChat = useCallback(() => {
    setMessages([initialMessage]);
    setDraft("");
    setLastFailedText(null);
    setVoiceError(null);
    setShowFavorites(false);
    Speech.stop().catch(() => undefined);
    setSpeakingMessageId(null);
  }, []);

  const shareMessage = useCallback(async (message: ChatMessage) => {
    const shareText = `RIFAT SHAHARIYA AI-এর উত্তর:\n\n${message.content}`;
    try {
      if (Platform.OS === "web" && typeof navigator !== "undefined" && "share" in navigator) {
        await (navigator as Navigator & { share: (data: { title: string; text: string }) => Promise<void> }).share({ title: "RIFAT SHAHARIYA AI", text: shareText });
        return;
      }
      if (Platform.OS === "web") {
        await Clipboard.setStringAsync(shareText);
        setCopiedMessageId(message.id);
        setVoiceError("শেয়ার মেনু পাওয়া যায়নি—উত্তরটি কপি হয়েছে।");
        return;
      }
      await Share.share({ title: "RIFAT SHAHARIYA AI", message: shareText });
    } catch {
      setVoiceError("উত্তরটি শেয়ার করা যায়নি।");
    }
  }, []);

  const transcribeRecording = useCallback(async (uri: string) => {
    setIsTranscribing(true);
    setVoiceError(null);
    try {
      const audioBase64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
      const result = await transcribeMutation.mutateAsync({ audioBase64, mimeType: Platform.OS === "web" ? "audio/webm" : "audio/m4a", language: "bn" });
      setDraft(result.text);
      await sendMessage(result.text);
    } catch {
      setVoiceError("কথাটি বোঝা যায়নি। আবার চেষ্টা করুন।");
    } finally {
      setIsTranscribing(false);
    }
  }, [sendMessage, transcribeMutation]);

  const startVoiceInput = useCallback(async () => {
    setVoiceError(null);
    if (Platform.OS === "web") {
      const SpeechRecognition = (globalThis as any).SpeechRecognition || (globalThis as any).webkitSpeechRecognition;
      if (!SpeechRecognition) {
        setVoiceError("এই ব্রাউজারে ভয়েস ইনপুট সমর্থিত নয়।");
        return;
      }
      const recognition = new SpeechRecognition();
      recognition.lang = "bn-BD";
      recognition.interimResults = false;
      recognition.continuous = false;
      recognition.onstart = () => setIsRecording(true);
      recognition.onresult = (event: any) => {
        const text = event.results?.[0]?.[0]?.transcript?.trim();
        if (text) {
          setDraft(text);
          sendMessage(text);
        }
      };
      recognition.onerror = () => setVoiceError("মাইক্রোফোন থেকে কথা নেওয়া যায়নি।");
      recognition.onend = () => setIsRecording(false);
      recognitionRef.current = recognition;
      recognition.start();
      return;
    }
    const permission = await requestRecordingPermissionsAsync();
    if (!permission.granted) {
      setVoiceError("মাইক্রোফোন ব্যবহারের অনুমতি প্রয়োজন।");
      return;
    }
    try {
      await recorder.prepareToRecordAsync();
      recorder.record();
      setIsRecording(true);
    } catch {
      setVoiceError("রেকর্ডিং শুরু করা যায়নি।");
    }
  }, [recorder, sendMessage]);

  const stopVoiceInput = useCallback(async () => {
    if (Platform.OS === "web") {
      recognitionRef.current?.stop?.();
      setIsRecording(false);
      return;
    }
    try {
      await recorder.stop();
      setIsRecording(false);
      if (recorder.uri) await transcribeRecording(recorder.uri);
    } catch {
      setIsRecording(false);
      setVoiceError("রেকর্ডিং বন্ধ করা যায়নি।");
    }
  }, [recorder, transcribeRecording]);

  const listHeader = useMemo(() => (
    <View style={styles.headerBlock}>
      <View style={styles.brandRow}>
        <Image source={require("@/assets/images/icon.png")} style={styles.brandMark} resizeMode="cover" accessibilityLabel="RIFAT SHAHARIYA AI লোগো" />
        <View>
          <Text style={styles.brandName}>RIFAT SHAHARIYA AI</Text>
          <Text style={styles.brandSubtitle}>আপনার দৈনন্দিন সহকারী</Text>
        </View>
        <View style={styles.headerActions}>
          <Pressable accessibilityLabel="ভয়েস সেটিংস খুলুন" onPress={() => setShowSettings((current) => !current)} style={({ pressed }) => [styles.clearButton, showSettings && styles.clearButtonActive, pressed && styles.pressed]}>
            <MaterialIcons name="settings-voice" size={20} color={showSettings ? "#FFFFFF" : "#4F46E5"} />
          </Pressable>
          <Pressable accessibilityLabel="সেভ করা উত্তর দেখুন" onPress={() => setShowFavorites((current) => !current)} style={({ pressed }) => [styles.clearButton, showFavorites && styles.clearButtonActive, pressed && styles.pressed]}>
            <MaterialIcons name="star" size={20} color={showFavorites ? "#FFFFFF" : "#4F46E5"} />
          </Pressable>
          <Pressable accessibilityLabel="নতুন চ্যাট শুরু করুন" onPress={startNewChat} style={({ pressed }) => [styles.clearButton, pressed && styles.pressed]}>
            <MaterialIcons name="add" size={22} color="#4F46E5" />
          </Pressable>
        </View>
      </View>
      <Pressable accessibilityRole="switch" accessibilityState={{ checked: autoSpeak }} accessibilityLabel="AI উত্তর স্বয়ংক্রিয়ভাবে পড়ে শোনান" onPress={toggleAutoSpeak} style={({ pressed }) => [styles.autoSpeakToggle, autoSpeak && styles.autoSpeakToggleActive, pressed && styles.pressed]}>
        <MaterialIcons name={autoSpeak ? "volume-up" : "volume-off"} size={17} color={autoSpeak ? "#FFFFFF" : "#4F46E5"} />
        <Text style={[styles.autoSpeakText, autoSpeak && styles.autoSpeakTextActive]}>{autoSpeak ? "স্বয়ংক্রিয় পড়া চালু" : "স্বয়ংক্রিয় পড়া বন্ধ"}</Text>
        <View style={[styles.toggleTrack, autoSpeak && styles.toggleTrackActive]}><View style={[styles.toggleThumb, autoSpeak && styles.toggleThumbActive]} /></View>
      </Pressable>
      <Pressable accessibilityLabel="রিফাত শাহরিয়ার সম্পর্কে জানুন" onPress={() => setShowAbout((current) => !current)} style={({ pressed }) => [styles.aboutLink, pressed && styles.pressed]}><MaterialIcons name="info-outline" size={15} color="#4F46E5" /><Text style={styles.aboutLinkText}>{showAbout ? "পরিচিতি বন্ধ করুন" : "রিফাত শাহরিয়ার সম্পর্কে জানুন"}</Text></Pressable>
      {showAbout && <View style={styles.aboutPanel}>
        <View style={styles.aboutHero}><Image source={require("@/assets/images/icon.png")} style={styles.aboutLogo} resizeMode="cover" /><View style={styles.aboutHeroText}><Text style={styles.aboutEyebrow}>নির্মাতা পরিচিতি</Text><Text style={styles.aboutName}>রিফাত শাহরিয়ার</Text><Text style={styles.aboutRole}>RIFAT SHAHARIYA AI-এর নির্মাতা</Text></View></View>
        <Text style={styles.aboutBody}>রিফাত শাহরিয়ার বাংলা ভাষাভাষী মানুষের জন্য সহজ, ব্যবহারবান্ধব ও কণ্ঠভিত্তিক AI সহায়তা তৈরি করছেন। এই অ্যাপের মাধ্যমে লেখা, প্রশ্ন, অনুবাদ, পরিকল্পনা এবং দৈনন্দিন কাজের সহায়তা এক জায়গায় পাওয়া যায়।</Text>
        <View style={styles.aboutDivider} />
        <Text style={styles.aboutSectionTitle}>এই অ্যাপে যা আছে</Text>
        <View style={styles.aboutFeatureGrid}><View style={styles.aboutFeature}><MaterialIcons name="chat-bubble-outline" size={17} color="#4F46E5" /><Text style={styles.aboutFeatureText}>বাংলা AI চ্যাট</Text></View><View style={styles.aboutFeature}><MaterialIcons name="mic-none" size={17} color="#4F46E5" /><Text style={styles.aboutFeatureText}>ভয়েস ইনপুট</Text></View><View style={styles.aboutFeature}><MaterialIcons name="volume-up" size={17} color="#4F46E5" /><Text style={styles.aboutFeatureText}>উত্তর শুনুন</Text></View><View style={styles.aboutFeature}><MaterialIcons name="share" size={17} color="#4F46E5" /><Text style={styles.aboutFeatureText}>কপি ও শেয়ার</Text></View></View>
        <Text style={styles.aboutQuote}>“বাংলায় AI ব্যবহারকে আরও সহজ, স্বাভাবিক ও সবার নাগালের মধ্যে নিয়ে আসাই এই উদ্যোগের লক্ষ্য।”</Text>
        <Text style={styles.aboutSectionTitle}>যোগাযোগ করুন</Text>
        <View style={styles.contactRow}><Pressable accessibilityLabel="Facebook-এ যোগাযোগ করুন" onPress={() => openContactLink(FACEBOOK_CONTACT_URL)} style={({ pressed }) => [styles.contactButton, styles.facebookButton, pressed && styles.pressed]}><MaterialIcons name="facebook" size={17} color="#FFFFFF" /><Text style={styles.contactButtonText}>Facebook</Text></Pressable><Pressable accessibilityLabel="WhatsApp-এ যোগাযোগ করুন" onPress={() => openContactLink(WHATSAPP_CONTACT_URL)} style={({ pressed }) => [styles.contactButton, styles.whatsappButton, pressed && styles.pressed]}><MaterialIcons name="chat" size={17} color="#FFFFFF" /><Text style={styles.contactButtonText}>WhatsApp</Text></Pressable></View>
        <Pressable accessibilityLabel="মতামত দিন" onPress={() => { setShowFeedback((current) => !current); setFeedbackStatus("idle"); }} style={({ pressed }) => [styles.feedbackButton, pressed && styles.pressed]}><MaterialIcons name="rate-review" size={17} color="#FFFFFF" /><Text style={styles.feedbackButtonText}>{showFeedback ? "ফিডব্যাক বন্ধ করুন" : "মতামত দিন"}</Text></Pressable>
        {showFeedback && <View style={styles.feedbackForm}><Text style={styles.feedbackLabel}>আপনার মতামত</Text><TextInput value={feedbackText} onChangeText={(text) => { setFeedbackText(text); setFeedbackStatus("idle"); }} placeholder="অ্যাপটি কেমন লাগছে? কী উন্নতি চান?" placeholderTextColor="#9CA3AF" multiline maxLength={1000} style={styles.feedbackInput} accessibilityLabel="আপনার মতামত লিখুন" /><Pressable accessibilityLabel="মতামত সংরক্ষণ করুন" onPress={submitFeedback} style={({ pressed }) => [styles.feedbackSubmit, pressed && styles.pressed]}><MaterialIcons name="send" size={16} color="#FFFFFF" /><Text style={styles.feedbackSubmitText}>মতামত সংরক্ষণ করুন</Text></Pressable>{feedbackStatus === "success" && <Text style={styles.feedbackSuccess}>আপনার মতামত সংরক্ষিত হয়েছে। ধন্যবাদ!</Text>}{feedbackStatus === "error" && <Text style={styles.feedbackError}>{feedbackText.trim() ? "মতামত সংরক্ষণ করা যায়নি। আবার চেষ্টা করুন।" : "দয়া করে আগে আপনার মতামত লিখুন।"}</Text>}</View>}
      </View>}
      {showSettings && <View style={styles.settingsPanel}>
        <View style={styles.settingsTitleRow}><MaterialIcons name="settings-voice" size={17} color="#4F46E5" /><Text style={styles.settingsTitle}>ভয়েস সেটিংস</Text></View>
        <Text style={styles.settingsLabel}>ভাষা</Text>
        <View style={styles.settingsChoices}>{[{ label: "বাংলা", value: "bn-BD" }, { label: "English", value: "en-US" }, { label: "हिन्दी", value: "hi-IN" }].map((option) => <Pressable key={option.value} onPress={() => setSpeechLanguage(option.value)} style={({ pressed }) => [styles.settingsChoice, speechLanguage === option.value && styles.settingsChoiceActive, pressed && styles.pressed]}><Text style={[styles.settingsChoiceText, speechLanguage === option.value && styles.settingsChoiceTextActive]}>{option.label}</Text></Pressable>)}</View>
        <Text style={styles.settingsLabel}>ডিভাইসের কণ্ঠ</Text>
        {availableVoices.filter((voice) => voice.language?.toLowerCase().startsWith(speechLanguage.split("-")[0])).slice(0, 4).map((voice) => <Pressable key={voice.identifier} onPress={() => setSelectedVoice(voice.identifier)} style={({ pressed }) => [styles.voiceChoice, selectedVoice === voice.identifier && styles.voiceChoiceActive, pressed && styles.pressed]}><MaterialIcons name={selectedVoice === voice.identifier ? "radio-button-checked" : "radio-button-unchecked"} size={16} color={selectedVoice === voice.identifier ? "#4F46E5" : "#9CA3AF"} /><Text style={styles.voiceChoiceText} numberOfLines={1}>{voice.name || voice.identifier}</Text></Pressable>)}
        {availableVoices.filter((voice) => voice.language?.toLowerCase().startsWith(speechLanguage.split("-")[0])).length === 0 && <Text style={styles.settingsHint}>এই ভাষার নির্দিষ্ট কণ্ঠ ডিভাইসে পাওয়া যায়নি; ডিফল্ট কণ্ঠ ব্যবহার হবে।</Text>}
        <View style={styles.rateRow}><Text style={styles.settingsLabel}>গতি</Text><View style={styles.rateControls}><Pressable accessibilityLabel="কথার গতি কমান" onPress={() => setSpeechRate((rate) => Math.max(0.6, Number((rate - 0.1).toFixed(2))))} style={styles.rateButton}><Text style={styles.rateButtonText}>−</Text></Pressable><Text style={styles.rateValue}>{speechRate.toFixed(1)}×</Text><Pressable accessibilityLabel="কথার গতি বাড়ান" onPress={() => setSpeechRate((rate) => Math.min(1.4, Number((rate + 0.1).toFixed(2))))} style={styles.rateButton}><Text style={styles.rateButtonText}>+</Text></Pressable></View></View>
      </View>}
      {showFavorites && favoriteMessages.length > 0 && (
        <View style={styles.favoritesPanel}>
          <View style={styles.favoritesTitleRow}><MaterialIcons name="star" size={16} color="#D97706" /><Text style={styles.favoritesTitle}>সেভ করা উত্তর</Text></View>
          {favoriteMessages.map((favorite) => <Text key={favorite.id} style={styles.favoritePreview} numberOfLines={2}>{favorite.content}</Text>)}
        </View>
      )}
      {showFavorites && favoriteMessages.length === 0 && <Text style={styles.noFavorites}>এখনও কোনো উত্তর সেভ করা হয়নি।</Text>}
      {messages.length <= 1 && (
        <View style={styles.emptyState}>
          <Text style={styles.greeting}>আজ কী নিয়ে সাহায্য চাই?</Text>
          <Text style={styles.greetingBody}>আপনার প্রশ্ন লিখুন, অথবা দ্রুত শুরু করতে নিচের একটি বিষয় বেছে নিন।</Text>
          <View style={styles.promptGrid}>
            {starterPrompts.map((prompt) => (
              <Pressable key={prompt} onPress={() => setDraft(prompt)} style={({ pressed }) => [styles.promptChip, pressed && styles.pressed]}>
                <Text style={styles.promptText}>{prompt}</Text>
                <MaterialIcons name="arrow-outward" size={15} color="#4F46E5" />
              </Pressable>
            ))}
          </View>
        </View>
      )}
    </View>
  ), [autoSpeak, availableVoices, favoriteMessages, feedbackStatus, feedbackText, messages.length, openContactLink, selectedVoice, showAbout, showFavorites, showFeedback, showSettings, speechLanguage, speechRate, startNewChat, submitFeedback, toggleAutoSpeak]);

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]} containerClassName="bg-background">
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined} keyboardVerticalOffset={Platform.OS === "ios" ? 6 : 0}>
        <FlatList
          data={messages}
          keyExtractor={(item) => item.id}
          ListHeaderComponent={listHeader}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <View style={[styles.messageRow, item.role === "user" && styles.userRow]}>
              {item.role === "assistant" && <View style={styles.avatar}><MaterialIcons name="auto-awesome" size={14} color="#4F46E5" /></View>}
              <View style={[styles.messageBubble, item.role === "user" ? styles.userBubble : styles.assistantBubble]}>
                <Text style={[styles.messageText, item.role === "user" && styles.userMessageText]}>{item.content}</Text>
                {item.role === "assistant" && (
                  <View style={styles.messageActions}>
                    <Pressable accessibilityLabel={speakingMessageId === item.id ? "উত্তর থামান" : "উত্তর শুনুন"} onPress={() => speakMessage(item)} style={({ pressed }) => [styles.listenButton, pressed && styles.pressed]}>
                      <MaterialIcons name={speakingMessageId === item.id ? "stop" : "volume-up"} size={16} color="#4F46E5" />
                      <Text style={styles.listenText}>{speakingMessageId === item.id ? "থামান" : "শুনুন"}</Text>
                    </Pressable>
                    <Pressable accessibilityLabel="AI-এর উত্তর কপি করুন" onPress={() => copyMessage(item)} style={({ pressed }) => [styles.listenButton, pressed && styles.pressed]}>
                      <MaterialIcons name={copiedMessageId === item.id ? "check" : "content-copy"} size={16} color="#4F46E5" />
                      <Text style={styles.listenText}>{copiedMessageId === item.id ? "কপি হয়েছে" : "কপি"}</Text>
                    </Pressable>
                    <Pressable accessibilityLabel={favoriteMessages.some((favorite) => favorite.id === item.id) ? "সেভ করা উত্তর সরান" : "উত্তর সেভ করুন"} onPress={() => toggleFavorite(item)} style={({ pressed }) => [styles.listenButton, pressed && styles.pressed]}>
                      <MaterialIcons name={favoriteMessages.some((favorite) => favorite.id === item.id) ? "star" : "star-border"} size={16} color="#D97706" />
                      <Text style={styles.listenText}>{favoriteMessages.some((favorite) => favorite.id === item.id) ? "সেভড" : "সেভ"}</Text>
                    </Pressable>
                    <Pressable accessibilityLabel="AI-এর উত্তর শেয়ার করুন" onPress={() => shareMessage(item)} style={({ pressed }) => [styles.listenButton, pressed && styles.pressed]}>
                      <MaterialIcons name="share" size={16} color="#4F46E5" />
                      <Text style={styles.listenText}>শেয়ার</Text>
                    </Pressable>
                  </View>
                )}
              </View>
            </View>
          )}
          ListFooterComponent={
            <View>
              {completion.isPending && <View style={styles.typingRow}><View style={styles.avatar}><MaterialIcons name="auto-awesome" size={14} color="#4F46E5" /></View><View style={styles.typingBubble}><TypingIndicator /><Text style={styles.typingText}>উত্তর তৈরি হচ্ছে…</Text></View></View>}
              {lastFailedText && <Pressable onPress={() => sendMessage(lastFailedText)} style={styles.errorCard}><MaterialIcons name="refresh" size={18} color="#DC2626" /><Text style={styles.errorText}>উত্তর পাওয়া যায়নি। আবার চেষ্টা করুন</Text></Pressable>}
              {voiceError && <View style={styles.voiceErrorCard}><MaterialIcons name="mic-off" size={17} color="#B91C1C" /><Text style={styles.errorText}>{voiceError}</Text></View>}
            </View>
          }
        />
        <View style={styles.composerWrap}>
          <NativeBannerAd />
          <View style={styles.composer}>
            <TextInput value={draft} onChangeText={setDraft} placeholder="আপনার প্রশ্ন লিখুন…" placeholderTextColor="#9CA3AF" multiline maxLength={4000} returnKeyType="send" onSubmitEditing={() => sendMessage()} style={styles.input} editable={!completion.isPending && !isRecording} accessibilityLabel="আপনার প্রশ্ন লিখুন" />
            <Pressable accessibilityLabel={isRecording ? "রেকর্ডিং থামান" : "ভয়েস ইনপুট চালু করুন"} onPress={isRecording ? stopVoiceInput : startVoiceInput} disabled={completion.isPending || isTranscribing} style={({ pressed }) => [styles.voiceButton, isRecording && styles.voiceButtonActive, (completion.isPending || isTranscribing) && styles.sendDisabled, pressed && styles.pressed]}>
              {isTranscribing ? <ActivityIndicator size="small" color="#4F46E5" /> : <MaterialIcons name={isRecording ? "stop" : "mic"} size={19} color={isRecording ? "#FFFFFF" : "#4F46E5"} />}
            </Pressable>
            <Pressable accessibilityLabel="বার্তা পাঠান" onPress={() => sendMessage()} disabled={!draft.trim() || completion.isPending} style={({ pressed }) => [styles.sendButton, (!draft.trim() || completion.isPending) && styles.sendDisabled, pressed && styles.pressed]}>
              <MaterialIcons name={completion.isPending ? "hourglass-top" : "arrow-upward"} size={20} color="#FFFFFF" />
            </Pressable>
          </View>
          <Text style={styles.disclaimer}>মাইক্রোফোনে বলুন, অথবা উত্তরের পাশে 🔊 চাপ দিয়ে শুনুন</Text>
        </View>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  listContent: { paddingHorizontal: 18, paddingBottom: 18 },
  headerBlock: { paddingTop: 14, paddingBottom: 16 },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 11 },
  headerActions: { marginLeft: "auto", flexDirection: "row", gap: 7 },
  brandMark: { width: 40, height: 40, borderRadius: 14, backgroundColor: "#071426" },
  brandName: { color: "#171717", fontSize: 16, fontWeight: "800", lineHeight: 22, maxWidth: 210 },
  brandSubtitle: { color: "#6B7280", fontSize: 12, marginTop: 1 },
  clearButton: { width: 40, height: 40, borderRadius: 13, backgroundColor: "#EEF2FF", alignItems: "center", justifyContent: "center" },
  clearButtonActive: { backgroundColor: "#D97706" },
  aboutLink: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 5, marginTop: 10, paddingVertical: 4 },
  aboutLinkText: { color: "#4F46E5", fontSize: 12, fontWeight: "800" },
  aboutPanel: { backgroundColor: "#F8FAFF", borderWidth: 1, borderColor: "#DDE4FF", borderRadius: 18, padding: 14, marginTop: 10, gap: 10 },
  aboutHero: { flexDirection: "row", alignItems: "center", gap: 11 },
  aboutLogo: { width: 54, height: 54, borderRadius: 16, backgroundColor: "#071426" },
  aboutHeroText: { flex: 1 },
  aboutEyebrow: { color: "#6366F1", fontSize: 10, fontWeight: "800", letterSpacing: 0.5, textTransform: "uppercase" },
  aboutName: { color: "#171717", fontSize: 20, fontWeight: "800", marginTop: 2 },
  aboutRole: { color: "#6B7280", fontSize: 12, marginTop: 2 },
  aboutBody: { color: "#4B5563", fontSize: 13, lineHeight: 20 },
  aboutDivider: { height: 1, backgroundColor: "#E4E7F5" },
  aboutSectionTitle: { color: "#3730A3", fontSize: 12, fontWeight: "800" },
  aboutFeatureGrid: { flexDirection: "row", flexWrap: "wrap", gap: 7 },
  aboutFeature: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#FFFFFF", borderRadius: 10, paddingHorizontal: 9, paddingVertical: 7 },
  aboutFeatureText: { color: "#4B5563", fontSize: 11, fontWeight: "700" },
  aboutQuote: { color: "#4F46E5", fontSize: 12, lineHeight: 18, fontStyle: "italic", backgroundColor: "#EEF2FF", borderRadius: 10, padding: 9 },
  contactRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  contactButton: { flexDirection: "row", alignItems: "center", gap: 7, borderRadius: 11, paddingHorizontal: 12, paddingVertical: 9 },
  facebookButton: { backgroundColor: "#1877F2" },
  whatsappButton: { backgroundColor: "#16A34A" },
  contactButtonText: { color: "#FFFFFF", fontSize: 12, fontWeight: "800" },
  feedbackButton: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 7, backgroundColor: "#4F46E5", borderRadius: 11, paddingHorizontal: 12, paddingVertical: 9 },
  feedbackButtonText: { color: "#FFFFFF", fontSize: 12, fontWeight: "800" },
  feedbackForm: { gap: 8, marginTop: 2 },
  feedbackLabel: { color: "#3730A3", fontSize: 12, fontWeight: "800" },
  feedbackInput: { minHeight: 76, borderWidth: 1, borderColor: "#DDE4FF", borderRadius: 12, backgroundColor: "#FFFFFF", color: "#292524", fontSize: 13, lineHeight: 19, paddingHorizontal: 11, paddingVertical: 9, textAlignVertical: "top" },
  feedbackSubmit: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 7, backgroundColor: "#3730A3", borderRadius: 10, paddingHorizontal: 11, paddingVertical: 8 },
  feedbackSubmitText: { color: "#FFFFFF", fontSize: 11, fontWeight: "800" },
  feedbackSuccess: { color: "#15803D", fontSize: 12, fontWeight: "700" },
  feedbackError: { color: "#B91C1C", fontSize: 12, fontWeight: "700" },
  settingsPanel: { backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E0E7FF", borderRadius: 16, padding: 13, marginTop: 12, gap: 8 },
  settingsTitleRow: { flexDirection: "row", alignItems: "center", gap: 7 },
  settingsTitle: { color: "#3730A3", fontSize: 13, fontWeight: "800" },
  settingsLabel: { color: "#6B7280", fontSize: 11, fontWeight: "700", marginTop: 3 },
  settingsChoices: { flexDirection: "row", flexWrap: "wrap", gap: 7 },
  settingsChoice: { borderWidth: 1, borderColor: "#E7E5E4", borderRadius: 10, paddingHorizontal: 10, paddingVertical: 7 },
  settingsChoiceActive: { backgroundColor: "#EEF2FF", borderColor: "#A5B4FC" },
  settingsChoiceText: { color: "#57534E", fontSize: 12, fontWeight: "700" },
  settingsChoiceTextActive: { color: "#4F46E5" },
  voiceChoice: { flexDirection: "row", alignItems: "center", gap: 7, paddingVertical: 4 },
  voiceChoiceActive: { backgroundColor: "#F8FAFC", borderRadius: 8 },
  voiceChoiceText: { color: "#44403C", fontSize: 12, flexShrink: 1 },
  settingsHint: { color: "#9CA3AF", fontSize: 11, lineHeight: 16 },
  rateRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 2 },
  rateControls: { flexDirection: "row", alignItems: "center", gap: 10 },
  rateButton: { width: 28, height: 28, borderRadius: 9, backgroundColor: "#EEF2FF", alignItems: "center", justifyContent: "center" },
  rateButtonText: { color: "#4F46E5", fontSize: 18, lineHeight: 20, fontWeight: "800" },
  rateValue: { color: "#3730A3", fontSize: 12, fontWeight: "800", minWidth: 30, textAlign: "center" },
  favoritesPanel: { backgroundColor: "#FFFBEB", borderWidth: 1, borderColor: "#FDE68A", borderRadius: 16, padding: 12, marginTop: 14, gap: 7 },
  favoritesTitleRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  favoritesTitle: { color: "#92400E", fontSize: 13, fontWeight: "800" },
  favoritePreview: { color: "#78350F", fontSize: 12, lineHeight: 18 },
  noFavorites: { color: "#92400E", fontSize: 12, marginTop: 14 },
  autoSpeakToggle: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 8, marginTop: 14, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E7E5E4", borderRadius: 14, paddingHorizontal: 11, paddingVertical: 8 },
  autoSpeakToggleActive: { backgroundColor: "#4F46E5", borderColor: "#4F46E5" },
  autoSpeakText: { color: "#4F46E5", fontSize: 12, fontWeight: "700" },
  autoSpeakTextActive: { color: "#FFFFFF" },
  toggleTrack: { width: 28, height: 17, borderRadius: 10, backgroundColor: "#E0E7FF", justifyContent: "center", paddingHorizontal: 2 },
  toggleTrackActive: { backgroundColor: "#A5B4FC" },
  toggleThumb: { width: 13, height: 13, borderRadius: 7, backgroundColor: "#4F46E5" },
  toggleThumbActive: { alignSelf: "flex-end", backgroundColor: "#FFFFFF" },
  emptyState: { marginTop: 30 },
  greeting: { color: "#171717", fontSize: 30, fontWeight: "800", lineHeight: 39, letterSpacing: -0.6 },
  greetingBody: { color: "#6B7280", fontSize: 14, lineHeight: 22, marginTop: 8, maxWidth: 340 },
  promptGrid: { flexDirection: "row", flexWrap: "wrap", gap: 9, marginTop: 22 },
  promptChip: { flexDirection: "row", alignItems: "center", gap: 7, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E7E5E4", borderRadius: 15, paddingHorizontal: 12, paddingVertical: 10 },
  promptText: { color: "#3730A3", fontSize: 13, fontWeight: "600" },
  messageRow: { flexDirection: "row", alignItems: "flex-end", gap: 8, marginBottom: 14, maxWidth: "92%" },
  userRow: { alignSelf: "flex-end", flexDirection: "row-reverse" },
  avatar: { width: 25, height: 25, borderRadius: 9, backgroundColor: "#EEF2FF", alignItems: "center", justifyContent: "center" },
  messageBubble: { flexShrink: 1, borderRadius: 18, paddingHorizontal: 14, paddingVertical: 11 },
  assistantBubble: { backgroundColor: "#FFFFFF", borderBottomLeftRadius: 5, borderWidth: 1, borderColor: "#EEECE9" },
  messageActions: { flexDirection: "row", alignItems: "center", gap: 14, marginTop: 9, paddingTop: 7, borderTopWidth: 1, borderTopColor: "#F1F0EE" },
  listenButton: { flexDirection: "row", alignItems: "center", gap: 5 },
  listenText: { color: "#4F46E5", fontSize: 11, fontWeight: "700" },
  userBubble: { backgroundColor: "#4F46E5", borderBottomRightRadius: 5 },
  messageText: { color: "#292524", fontSize: 15, lineHeight: 23 },
  userMessageText: { color: "#FFFFFF" },
  typingRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 14 },
  typingBubble: { flexDirection: "row", alignItems: "center", gap: 9, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#EEECE9", borderRadius: 18, paddingHorizontal: 14, paddingVertical: 11 },
  typingDots: { flexDirection: "row", alignItems: "center", gap: 4, minWidth: 28 },
  typingDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#4F46E5" },
  typingText: { color: "#6B7280", fontSize: 13 },
  errorCard: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "#FEF2F2", borderRadius: 14, padding: 12, marginBottom: 12 },
  voiceErrorCard: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "#FEF2F2", borderRadius: 14, padding: 11, marginBottom: 12 },
  errorText: { color: "#B91C1C", fontSize: 13, fontWeight: "600" },
  composerWrap: { paddingHorizontal: 16, paddingTop: 8, paddingBottom: Platform.OS === "ios" ? 8 : 12, backgroundColor: "#F7F5F2" },
  composer: { flexDirection: "row", alignItems: "flex-end", gap: 9, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E7E5E4", borderRadius: 20, paddingLeft: 15, paddingVertical: 7, paddingRight: 7 },
  input: { flex: 1, color: "#171717", fontSize: 15, lineHeight: 22, maxHeight: 100, paddingTop: 8, paddingBottom: 8 },
  voiceButton: { width: 38, height: 38, borderRadius: 14, backgroundColor: "#EEF2FF", alignItems: "center", justifyContent: "center" },
  voiceButtonActive: { backgroundColor: "#DC2626" },
  sendButton: { width: 38, height: 38, borderRadius: 14, backgroundColor: "#4F46E5", alignItems: "center", justifyContent: "center" },
  sendDisabled: { backgroundColor: "#C7D2FE" },
  disclaimer: { color: "#9CA3AF", fontSize: 10, textAlign: "center", marginTop: 8 },
  authGate: { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 28 },
  authLogo: { width: 96, height: 96, borderRadius: 28, backgroundColor: "#071426", marginBottom: 18 },
  authTitle: { color: "#171717", fontSize: 24, fontWeight: "800", textAlign: "center" },
  authBody: { color: "#6B7280", fontSize: 14, lineHeight: 22, textAlign: "center", marginTop: 10, maxWidth: 340 },
  authLoadingText: { color: "#6B7280", fontSize: 13, marginTop: 12 },
  loginButton: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "#4F46E5", borderRadius: 16, paddingHorizontal: 18, paddingVertical: 13, marginTop: 22 },
  loginButtonText: { color: "#FFFFFF", fontSize: 14, fontWeight: "800" },
  pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] },
});
