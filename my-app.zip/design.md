# Bangla AI Chat — Mobile Interface Design

## Product Direction

Bangla AI Chat is a calm, friendly, Bengali-first AI assistant for everyday questions, writing help, translation, study support, and brainstorming. The first release prioritizes a single-handed portrait experience, fast message composition, readable responses, and clear feedback while the assistant is working.

## Screen List

| Screen | Primary content and functionality |
|---|---|
| Chat Home | Greeting, current conversation, suggested prompt chips, message composer, send action, clear conversation action, and an optional compact assistant status indicator. |
| Conversation History | Locally saved conversation sessions with titles, relative dates, and actions to reopen or delete a session. |
| Assistant Settings | Language preference, response style preference, theme preference, and a short privacy note explaining local history behavior. |
| About / Help | Product identity, supported use cases, usage tips, and a simple feedback entry point. |

## Chat Home Layout

The screen uses a warm off-white background with a deep indigo header. The header contains the assistant mark, the Bengali product name “বাংলা AI”, and a compact overflow/settings action. The conversation body is a vertically scrolling list with generous spacing and high-contrast text. User messages use a soft indigo bubble aligned to the right; assistant messages use a white surface card aligned to the left with a small assistant avatar and a subtle indigo accent line.

At the empty state, the screen shows “আজ কী নিয়ে সাহায্য চাই?” followed by a short explanation and four prompt chips: “একটি ইমেইল লিখুন”, “সহজ ভাষায় বুঝিয়ে দিন”, “ইংরেজিতে অনুবাদ করুন”, and “পড়াশোনার পরিকল্পনা দিন”. Tapping a chip places the text into the composer and keeps the user in control before sending.

The composer is anchored above the home indicator with a rounded surface, multiline text input, attachment affordance reserved for a later release, and a filled send button. The send button is disabled when the input is empty and changes to a loading/stop state while the assistant is responding. Keyboard submission uses the send action rather than inserting an unexpected newline.

## Key User Flows

### Start a conversation

1. The user opens Chat Home and sees the Bengali greeting and suggested prompts.
2. The user taps a prompt chip or writes a message in the composer.
3. The user taps Send; the user message appears immediately and the composer clears.
4. A typing indicator appears while the response is requested.
5. The assistant response is appended to the conversation, and the user can continue naturally.

### Continue a saved conversation

1. The user opens Conversation History from the header action.
2. The user taps a saved session.
3. The app restores the messages from local storage and returns to Chat Home.

### Reset the current conversation

1. The user taps the clear action in the header.
2. A confirmation sheet explains that the current conversation will be removed from the active view.
3. The user confirms, returning to the empty state.

## Interaction and Accessibility

The design uses large touch targets, explicit disabled states, readable line heights, and labels for icon-only actions. Primary actions receive light haptic feedback on native platforms. The interface avoids relying on color alone to communicate loading, errors, or disabled states. Text remains selectable in assistant responses where practical, and the app should remain usable with larger system font sizes.

## Color Choices

| Token | Color | Purpose |
|---|---|---|
| Background | `#F7F5F2` | Warm paper-like screen background |
| Surface | `#FFFFFF` | Message cards, composer, and sheets |
| Primary | `#4F46E5` | Send action, active controls, assistant accents |
| Primary dark | `#3730A3` | Pressed states and strong indigo surfaces |
| Foreground | `#171717` | Main text and headings |
| Muted | `#6B7280` | Supporting text and timestamps |
| Border | `#E7E5E4` | Dividers and input outlines |
| User bubble | `#E0E7FF` | User message background |
| Success | `#16A34A` | Connected/ready status |
| Error | `#DC2626` | Request failure and recovery messaging |

## Typography and Tone

Use a system sans-serif with Bengali glyph support, medium-weight headings, and relaxed body line height. Copy should be warm, concise, and respectful. The assistant should address the user with “আপনি” and avoid overly technical wording in empty states and error messages.
