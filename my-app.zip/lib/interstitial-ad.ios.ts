export type InterstitialController = {
  showIfReady: () => void;
  dispose: () => void;
};

export function createInterstitialController(): InterstitialController {
  return {
    showIfReady: () => undefined,
    dispose: () => undefined,
  };
}
