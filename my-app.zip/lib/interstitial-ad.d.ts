export type InterstitialController = {
  showIfReady: () => void;
  dispose: () => void;
};

export function createInterstitialController(): InterstitialController;
