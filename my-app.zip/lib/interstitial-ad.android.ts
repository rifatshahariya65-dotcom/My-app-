import { AdEventType, InterstitialAd } from "react-native-google-mobile-ads";

const INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-8242783458530893/2914514856";

export type InterstitialController = {
  showIfReady: () => void;
  dispose: () => void;
};

export function createInterstitialController(): InterstitialController {
  let current = InterstitialAd.createForAdRequest(INTERSTITIAL_AD_UNIT_ID, { requestNonPersonalizedAdsOnly: true });
  let loaded = false;
  let unsubscribe = current.addAdEventListener(AdEventType.LOADED, () => {
    loaded = true;
  });
  current.load();

  return {
    showIfReady: () => {
      if (!loaded) return;
      const ad = current;
      loaded = false;
      ad.show().catch(() => undefined);
      current = InterstitialAd.createForAdRequest(INTERSTITIAL_AD_UNIT_ID, { requestNonPersonalizedAdsOnly: true });
      unsubscribe();
      unsubscribe = current.addAdEventListener(AdEventType.LOADED, () => {
        loaded = true;
      });
      current.load();
    },
    dispose: () => {
      unsubscribe();
      loaded = false;
    },
  };
}
