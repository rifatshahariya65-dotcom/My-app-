/** @type {const} */
const themeColors = {
  primary: { light: '#4F46E5', dark: '#818CF8' },
  background: { light: '#F7F5F2', dark: '#171717' },
  surface: { light: '#FFFFFF', dark: '#262626' },
  foreground: { light: '#171717', dark: '#FAFAF9' },
  muted: { light: '#6B7280', dark: '#A8A29E' },
  border: { light: '#E7E5E4', dark: '#44403C' },
  success: { light: '#22C55E', dark: '#4ADE80' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };
