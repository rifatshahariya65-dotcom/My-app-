# Project TODO

- [x] Initialize the Expo mobile project
- [x] Define Bengali-first mobile interface design and core user flows
- [x] Generate and configure a custom Bangla AI app logo
- [x] Replace the starter home screen with the Bengali AI chat experience
- [x] Add local conversation state and persistence
- [x] Add server-backed AI response handling using the built-in LLM capability
- [x] Add loading, error, retry, clear, and empty states
- [ ] Add conversation history and assistant settings surfaces
- [x] Update theme colors and app branding configuration
- [x] Add or update icon mappings for chat actions
- [x] Run type checking, linting, and tests
- [x] Verify the app preview at desktop and mobile viewport sizes
- [ ] Save the final checkpoint and deliver the project version

- [x] Rename the app to “রিফাত শাহরিয়ার এয়াই” across Expo display branding

- [x] Add microphone recording and speech-to-text input
- [x] Add AI response text-to-speech playback controls
- [x] Add voice permission, recording, playback, loading, and error states
- [x] Verify voice interactions on supported mobile and web environments

- [x] Add a persistent auto-speak toggle for newly generated AI responses
- [x] Verify auto-speak and manual listen behavior together

- [x] Rename the app to “RIFAT SHAHARIYA AI” across Expo display branding

- [x] Replace the app icon, splash icon, favicon, and Android icon with the provided RIFAT SHAHARIYA AI logo
- [x] Update Expo logo metadata and verify the new branding assets

- [x] Add a copy button to every AI response with success feedback

- [x] Add a New Chat action that clears the active conversation and starts fresh
- [x] Add saved/favorite state for important AI responses
- [x] Add share actions for AI responses using the native/system share sheet
- [x] Gate AI responses behind secure OAuth authentication
- [x] Add a clear authenticated and unauthenticated experience without collecting provider passwords

- [x] Add an animated Bengali typing/loading indicator while AI responses are generating
- [x] Verify the indicator appears during generation and disappears after completion

- [x] Add voice/language settings for AI speech playback
- [x] Persist selected language, device voice, and speaking speed
- [x] Verify manual listen and auto-speak use the selected settings

- [x] Remove mandatory login gate so users can enter and use AI without authentication
- [x] Allow unauthenticated AI and voice requests where currently blocked
- [x] Configure the assistant to say “আমাকে রিফাত শাহরিয়া তৈরি করছে” when asked who created it
- [x] Verify no-login access and creator identity response

- [x] Add an About/পরিচিতি panel for Rifat Shahariya and RIFAT SHAHARIYA AI
- [x] Use only verified creator and product information without inventing personal details
- [x] Add a visible About access point and verify the panel on mobile

- [x] Add a “মতামত দিন” feedback button inside the About panel
- [x] Add feedback input with empty, success, and error states
- [x] Verify feedback interaction on mobile

- [x] Add the provided Facebook link to the About panel
- [x] Add the provided WhatsApp link to the About panel
- [x] Verify both contact actions on mobile

- [x] Add the provided Google AdMob App ID and ad unit configuration
- [x] Add a native mobile banner ad with a safe Web fallback
- [x] Add a native mobile full-screen interstitial ad flow
- [x] Verify ad configuration and preserve the existing chat experience

- [ ] Add a separate iOS AdMob App ID to enable iOS ads
