import { BannerAd, BannerAdSize } from "react-native-google-mobile-ads";
import { StyleSheet, View } from "react-native";

const BANNER_AD_UNIT_ID = "ca-app-pub-8242783458530893/1561904738";

export function NativeBannerAd() {
  return (
    <View style={styles.wrap}>
      <BannerAd
        unitId={BANNER_AD_UNIT_ID}
        size={BannerAdSize.ANCHORED_ADAPTIVE_BANNER}
        requestOptions={{ requestNonPersonalizedAdsOnly: true }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    alignItems: "center",
    justifyContent: "center",
    minHeight: 50,
    marginBottom: 8,
    overflow: "hidden",
  },
});
