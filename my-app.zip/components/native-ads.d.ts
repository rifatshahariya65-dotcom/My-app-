export function NativeBannerAd(): React.ReactElement | null;
