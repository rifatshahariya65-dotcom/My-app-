export function NativeBannerAd() {
  return null;
}
