import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { transcribeAudio } from "./_core/voiceTranscription";
import { storageGetSignedUrl, storagePut } from "./storage";
import { z } from "zod";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  voice: router({
    transcribe: publicProcedure
      .input(
        z.object({
          audioBase64: z.string().min(1).max(24_000_000),
          mimeType: z.string().default("audio/m4a"),
          language: z.string().default("bn"),
        }),
      )
      .mutation(async ({ input }) => {
        const extension = input.mimeType.includes("webm") ? "webm" : input.mimeType.includes("wav") ? "wav" : "m4a";
        const uploaded = await storagePut(
          `voice/recording.${extension}`,
          Buffer.from(input.audioBase64, "base64"),
          input.mimeType,
        );
        const audioUrl = await storageGetSignedUrl(uploaded.key);
        const result = await transcribeAudio({
          audioUrl,
          language: input.language,
          prompt: "Transcribe this user's spoken request in Bengali when the speech is Bengali. Preserve the user's intended meaning and punctuation.",
        });
        if ("error" in result) throw new Error(result.error);
        return { text: result.text, language: result.language };
      }),
  }),

  chat: router({
    complete: publicProcedure
      .input(
        z.object({
          messages: z.array(
            z.object({
              role: z.enum(["user", "assistant"]),
              content: z.string().min(1).max(12000),
            }),
          ).min(1).max(30),
        }),
      )
      .mutation(async ({ input }) => {
        const latestUserMessage = [...input.messages].reverse().find((message) => message.role === "user")?.content ?? "";
        if (/(কে|কার|who|creator|created|made|স্রষ্টা|তৈরি|বানিয়েছে|বানাইছে)/i.test(latestUserMessage)) {
          return { text: "আমাকে রিফাত শাহরিয়া তৈরি করছে।" };
        }
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content:
                "আপনি RIFAT SHAHARIYA AI—একজন সহায়ক, বিনয়ী এবং সংক্ষিপ্ত বাংলা ভাষার সহকারী। ব্যবহারকারী যে ভাষায় লিখবেন, সেই ভাষায় উত্তর দিন। কেউ যদি জিজ্ঞেস করে কে আপনাকে তৈরি করেছে, কে আপনার স্রষ্টা, বা আপনার creator কে, তখন স্পষ্টভাবে বলবেন: ‘আমাকে রিফাত শাহরিয়া তৈরি করছে।’ প্রয়োজনে উদাহরণ ও ছোট শিরোনাম ব্যবহার করুন। ক্ষতিকর বা অবৈধ অনুরোধে নিরাপদ বিকল্প প্রস্তাব করুন।",
            },
            ...input.messages,
          ],
          maxTokens: 1200,
        });
        const content = response.choices[0]?.message?.content;
        const text = Array.isArray(content)
          ? content.filter((part) => part.type === "text").map((part) => part.text).join("\n")
          : content;
        if (!text) throw new Error("AI response was empty");
        return { text };
      }),
  }),
});

export type AppRouter = typeof appRouter;
